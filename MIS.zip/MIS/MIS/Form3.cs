﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace MIS
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        public string username;
        private void toolStripMenuItem19_Click(object sender, EventArgs e)
        {
          
        }


        private void 切换账号ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            login f = new login();
            f.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            this.Close();
            Form2 form = new Form2();
            form.username = username;
            form.Show();
        }

        private void 查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Form3 form = new Form3();
            form.username = username;
            form.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Close();
            Geren form = new Geren();
            form.username = username;
            form.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //逻辑判断  //声明变量
            String name1 = ""; //
            String bianhao1 = "";//
            String zuozhe1 = "";//




            //获取数据
            name1 = tbname1.Text;
            bianhao1 = tbbianhao1.Text;
            zuozhe1 = tbzuozhe1.Text;

            DB.RenjiEntities db = new DB.RenjiEntities();
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "select * from dbo.book where 1=1";//SQL语句实现表数据的读取
            if (name1 != "")
            {
                sql += "and name like '%" + name1.Replace("'", "''") + "%'";
            }
            if (bianhao1 != "")
            {
                sql += "and bianhao like '%" + bianhao1.Replace("'", "''") + "%'";
            }
            if (zuozhe1 != "")
            {
                sql += "and zuozhe like '%" + zuozhe1.Replace("'", "''") + "%'";
            }
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            DataSet dataSet = new DataSet(); //定义一个数据集
            SqlDataAdapter da = new SqlDataAdapter(sqlCommand);


            da.Fill(dataSet);   //填充数据集
            dataGridView2.DataSource = dataSet.Tables[0]; //填充数据进控件
            this.dataGridView2.Columns[0].DataPropertyName = dataSet.Tables[0].Columns[0].ToString();
            this.dataGridView2.Columns[1].DataPropertyName = dataSet.Tables[0].Columns[1].ToString();
            this.dataGridView2.Columns[2].DataPropertyName = dataSet.Tables[0].Columns[2].ToString();
            this.dataGridView2.Columns[3].DataPropertyName = dataSet.Tables[0].Columns[3].ToString();
            this.dataGridView2.Columns[4].DataPropertyName = dataSet.Tables[0].Columns[4].ToString();
            this.dataGridView2.Columns["id"].Visible = false;
            this.dataGridView2.Columns["name"].Visible = false;
            this.dataGridView2.Columns["zuozhe"].Visible = false;

            this.dataGridView2.Columns["bianhao"].Visible = false;

            this.dataGridView2.Columns["beizhu"].Visible = false;


            /*var model = db.books.Select(m =>
                new
                {
                    name = m.name,
                    bianhao = m.bianhao,
                    zuozhe=m.zuozhe,
                    beizhu=m.beizhu
                });


          
            if (name1 != ""&&bianhao1!=""&&zuozhe1!="")
            {
                model = model.Where(m => m.name.IndexOf(name1) >= 0);
            }
            dataGridView2.DataSource = model.ToList();**/
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string myConn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";
            SqlConnection sqlConnection = new SqlConnection(myConn);  //实例化连接对象
            sqlConnection.Open();

            String sql = "INSERT INTO dbo.dingdan(bookbianhao,username) VALUES('" + this.dataGridView2.CurrentRow.Cells[2].Value + "','" + username + "')";//SQL语句向表中写入数据
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            sqlCommand.ExecuteNonQuery();
            MessageBox.Show("借阅成功");
            sqlConnection.Close();
        }
    }
}
