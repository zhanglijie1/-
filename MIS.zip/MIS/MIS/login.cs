﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace MIS
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    
        private void denglu_Click(object sender, EventArgs e)
        {
            //声明变量
            String username = ""; //用户名
            String password = "";//密码
            String type = "";


            //获取数据
            username = tbUsername.Text;
            password = tbPassword.Text;
            type = comboBox1.SelectedItem.ToString();
            //逻辑判断


            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "select username,password from dbo.login where username='" + username + "'and password='" + password + "' and type='"+ type+"'";//SQL语句实现表数据的读取
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();//执行
            if (sqlDataReader.HasRows)//满足用户名与密码一致，进入下一个界面
            {
                this.Hide();
                if (type.Equals("管理员")) { 
                Main f1 = new Main();
                f1.username = username;
                f1.ShowDialog();//转换界面
            }
                else
                {
                  
                    Form2 f1 = new Form2();
                    f1.username = username;
                    f1.ShowDialog();//转换界面
                }
            }
            else//如果登录失败，询问是否注册新用户
            {
                MessageBox.Show("账号或密码错误");
            }
            sqlConnection.Close();
        }
    

        private void tuichu_Click(object sender, EventArgs e)
        {
            this.Close();  //退出按钮单击处理程序
        }

      

        private void button1_Click(object sender, EventArgs e)
        {
          
            zhuce frmMain = new zhuce();
            frmMain.Show();//转换界面

        }

      
    }
}
