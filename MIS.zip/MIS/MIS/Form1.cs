﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace MIS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public string id;

        private void Form1_Load(object sender, EventArgs e)
        {
        
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "select * from dbo.book where id ='"+id+"'";//SQL语句实现表数据的读取
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            SqlDataReader da = sqlCommand.ExecuteReader();//执行
            while (da.Read())
            {
                tbname.Text = Convert.ToString(da[1]);
                tbbianhao.Text = Convert.ToString(da[2]);
                tbzuozhe.Text = Convert.ToString(da[3]);
                tbbeizhu.Text = Convert.ToString(da[4]);
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            String a = "";
            String b = "";
            String c = "";
            String d = "";
            a=tbname.Text;
            b=tbbianhao.Text;
            c=tbzuozhe.Text;
            d=tbbeizhu.Text;
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "update dbo.book set name='" +a+ "',bianhao='" + b + "',zuozhe='" + c + "',beizhu='" + d + "' where id ='" + id + "'";//SQL语句实现表数据的读取
            Console.WriteLine(sql);
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            SqlDataReader da1 = sqlCommand.ExecuteReader();//执行
          
                MessageBox.Show("修改成功");
            
        }
    }
}
