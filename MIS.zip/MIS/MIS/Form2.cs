﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace MIS
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public string username;
        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripMenuItem3_Click_1(object sender, EventArgs e)
        {
            this.Close();
            Form2 form = new Form2();
            form.username = username;
            form.Show();
        }

        private void 查询ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Close();
            Form3 form = new Form3();
            form.username = username;
            form.Show();
        }

        private void toolStripMenuItem2_Click_1(object sender, EventArgs e)
        {
            this.Close();
            Geren form = new Geren();
            form.username = username;
            form.Show();
        }

        private void 切换账号ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            login f = new login();
          
            f.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void Display()
        {
            //逻辑判断

            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "select * from dbo.book";//SQL语句实现表数据的读取
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            DataSet dataSet = new DataSet(); //定义一个数据集
            SqlDataAdapter da = new SqlDataAdapter(sqlCommand);
            da.Fill(dataSet);   //填充数据集
            dataGridView1.DataSource = dataSet.Tables[0]; //填充数据进控件


            this.dataGridView1.Columns[0].DataPropertyName = dataSet.Tables[0].Columns[0].ToString();
            this.dataGridView1.Columns[1].DataPropertyName = dataSet.Tables[0].Columns[1].ToString();
            this.dataGridView1.Columns[2].DataPropertyName = dataSet.Tables[0].Columns[2].ToString();
            this.dataGridView1.Columns[3].DataPropertyName = dataSet.Tables[0].Columns[3].ToString();
            this.dataGridView1.Columns[4].DataPropertyName = dataSet.Tables[0].Columns[4].ToString();
            this.dataGridView1.Columns["id"].Visible = false;

            this.dataGridView1.Columns["name"].Visible = false;
            this.dataGridView1.Columns["zuozhe"].Visible = false;

            this.dataGridView1.Columns["bianhao"].Visible = false;

            this.dataGridView1.Columns["beizhu"].Visible = false;


        }
        private void Form2_Load(object sender, EventArgs e)
        {
            Display();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Display();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string myConn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";
            SqlConnection sqlConnection = new SqlConnection(myConn);  //实例化连接对象
            sqlConnection.Open();

            String sql = "INSERT INTO dbo.dingdan(bookbianhao,username) VALUES('" + this.dataGridView1.CurrentRow.Cells[2].Value + "','" + username + "')";//SQL语句向表中写入数据
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            sqlCommand.ExecuteNonQuery();
            MessageBox.Show("借阅成功");
            sqlConnection.Close();
        }

      
    }
}
