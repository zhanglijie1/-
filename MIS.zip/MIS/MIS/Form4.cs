﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace MIS
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        public string username;
        private void button1_Click(object sender, EventArgs e)
        {
            String a = "";
            String b = "";
            String c = "";
            String d = "";
            a = tbname.Text;
            b = tbsex.Text;
            c = tbhobby.Text;
            d = tbpassword.Text;
         
         
        

            DB.RenjiEntities db = new DB.RenjiEntities();
        
            String sql = "update dbo.login set name='" + a + "',sex='" + b + "',hobby='" + c + "',password='" + d + "' where username ='" + username + "'";//SQL语句实现表数据的读取
            //SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            //sqlCommand.ExecuteNonQuery();
            db.Database.ExecuteSqlCommand(sql);
            MessageBox.Show("修改成功");
            this.Hide();
            Geren g = new Geren();
            g.username = username;
            g.ShowDialog();
            
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "select name,sex,hobby from dbo.login where username='" + username + "'";//SQL语句实现表数据的读取
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();//执行
            while (sqlDataReader.Read())
            {//满足用户名与密码一致，进入下一个界面
                tbname.Text = (string)sqlDataReader[0];
                tbsex.Text = (string)sqlDataReader[1];
                tbhobby.Text = (string)sqlDataReader[2];
   

            }
        }
    }
}
