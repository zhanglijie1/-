﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;


namespace MIS
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        public string username;//public类型的实例字段
        private void Main_Load(object sender, EventArgs e)
        {

            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "select * from dbo.book";//SQL语句实现表数据的读取
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            DataSet dataSet = new DataSet(); //定义一个数据集
            SqlDataAdapter da = new SqlDataAdapter(sqlCommand);
            da.Fill(dataSet);   //填充数据集
            dataGridView1.DataSource = dataSet.Tables[0]; //填充数据进控件
            /*DataGridViewButtonColumn edit = new DataGridViewButtonColumn();
            edit.HeaderCell.Value = "操作";
            edit.Name = "edit";
            edit.Text = "编辑";
            edit.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(edit);

            DataGridViewButtonColumn del = new DataGridViewButtonColumn();
            del.HeaderCell.Value = "操作";
            del.Name = "del";
            del.Text = "删除";
            del.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(del);**/

            this.dataGridView1.Columns[0].DataPropertyName = dataSet.Tables[0].Columns[0].ToString();
            this.dataGridView1.Columns[1].DataPropertyName = dataSet.Tables[0].Columns[1].ToString();
            this.dataGridView1.Columns[2].DataPropertyName = dataSet.Tables[0].Columns[2].ToString();
            this.dataGridView1.Columns[3].DataPropertyName = dataSet.Tables[0].Columns[3].ToString();
            this.dataGridView1.Columns[4].DataPropertyName = dataSet.Tables[0].Columns[4].ToString();
            this.dataGridView1.Columns["id"].Visible = false;

            this.dataGridView1.Columns["name"].Visible = false;
            this.dataGridView1.Columns["zuozhe"].Visible = false;

            this.dataGridView1.Columns["bianhao"].Visible = false;

            this.dataGridView1.Columns["beizhu"].Visible = false;
            sqlConnection.Close();
            Display1();
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {

            if (MessageBox.Show("关闭窗体后，程序会退出！！", "！！提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                e.Cancel = false;
                Application.Exit();
            }
            else
            {
                e.Cancel = true;
            }


        }
        public void Display()
        {
            //逻辑判断

            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "select * from dbo.book";//SQL语句实现表数据的读取
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            DataSet dataSet = new DataSet(); //定义一个数据集
            SqlDataAdapter da = new SqlDataAdapter(sqlCommand);
            da.Fill(dataSet);   //填充数据集
            dataGridView1.DataSource = dataSet.Tables[0]; //填充数据进控件


            this.dataGridView1.Columns[0].DataPropertyName = dataSet.Tables[0].Columns[0].ToString();
            this.dataGridView1.Columns[1].DataPropertyName = dataSet.Tables[0].Columns[1].ToString();
            this.dataGridView1.Columns[2].DataPropertyName = dataSet.Tables[0].Columns[2].ToString();
            this.dataGridView1.Columns[3].DataPropertyName = dataSet.Tables[0].Columns[3].ToString();
            this.dataGridView1.Columns[4].DataPropertyName = dataSet.Tables[0].Columns[4].ToString();
            this.dataGridView1.Columns["id"].Visible = false;

            this.dataGridView1.Columns["name"].Visible = false;
            this.dataGridView1.Columns["zuozhe"].Visible = false;

            this.dataGridView1.Columns["bianhao"].Visible = false;

            this.dataGridView1.Columns["beizhu"].Visible = false;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            if (Convert.ToString(this.dataGridView1.CurrentRow.Cells[0].Value) != null)//转化类型
            {
                String sql = "delete from dbo.book where id =" + this.dataGridView1.CurrentRow.Cells[0].Value + "";
                SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
                MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
                DialogResult dr = MessageBox.Show("确定要删除吗?", "", messButton);
                if (dr == DialogResult.OK)//如果点击“确定”按钮
                {

                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();//执行

                    MessageBox.Show("删除成功");
                }
                else
                {

                }
            }
            sqlConnection.Close();
            Display();
        }


        private void button2_Click(object sender, EventArgs e)
        {


            Display();



        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            login login = new login();
            login.Show();//转换界面
        }

        private void 主页_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            //声明变量
            String name = ""; //
            String bianhao = "";//
            String zuozhe = "";//
            String beizhu = "";//



            //获取数据
            name = tbname.Text;
            bianhao = tbbianhao.Text;
            zuozhe = tbzuozhe.Text;
            beizhu = tbbeizhu.Text;



            string myConn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";
            SqlConnection sqlConnection = new SqlConnection(myConn);  //实例化连接对象
            sqlConnection.Open();

            String sql = "INSERT INTO dbo.book(name,bianhao,zuozhe,beizhu) VALUES('" + name + "','" + bianhao + "','" + zuozhe + "','" + beizhu + "')";//SQL语句向表中写入数据
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            sqlCommand.ExecuteNonQuery();
            MessageBox.Show("添加成功");
            sqlConnection.Close();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            //逻辑判断  //声明变量
            String name1 = ""; //
            String bianhao1 = "";//
            String zuozhe1 = "";//




            //获取数据
            name1 = tbname1.Text;
            bianhao1 = tbbianhao1.Text;
            zuozhe1 = tbzuozhe1.Text;

            DB.RenjiEntities db = new DB.RenjiEntities();
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "select * from dbo.book where 1=1";//SQL语句实现表数据的读取
            if (name1!="")
            {
                sql += "and name like '%" + name1.Replace("'", "''") + "%'";
            }
           if (bianhao1!="")
            {
                sql += "and bianhao like '%" + bianhao1.Replace("'", "''") + "%'";
            }
          if (zuozhe1!="")
            {
                sql += "and zuozhe like '%" + zuozhe1.Replace("'", "''") + "%'";
            }
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            DataSet dataSet = new DataSet(); //定义一个数据集
            SqlDataAdapter da = new SqlDataAdapter(sqlCommand);
          
         
                da.Fill(dataSet);   //填充数据集
                dataGridView2.DataSource = dataSet.Tables[0]; //填充数据进控件
                this.dataGridView2.Columns[0].DataPropertyName = dataSet.Tables[0].Columns[0].ToString();
                this.dataGridView2.Columns[1].DataPropertyName = dataSet.Tables[0].Columns[1].ToString();
                this.dataGridView2.Columns[2].DataPropertyName = dataSet.Tables[0].Columns[2].ToString();
                this.dataGridView2.Columns[3].DataPropertyName = dataSet.Tables[0].Columns[3].ToString();
                this.dataGridView2.Columns[4].DataPropertyName = dataSet.Tables[0].Columns[4].ToString();
                this.dataGridView2.Columns["id"].Visible = false;
                this.dataGridView2.Columns["name"].Visible = false;
                this.dataGridView2.Columns["zuozhe"].Visible = false;

                this.dataGridView2.Columns["bianhao"].Visible = false;

                this.dataGridView2.Columns["beizhu"].Visible = false;
            
           
            /*var model = db.books.Select(m =>
                new
                {
                    name = m.name,
                    bianhao = m.bianhao,
                    zuozhe=m.zuozhe,
                    beizhu=m.beizhu
                });


          
            if (name1 != ""&&bianhao1!=""&&zuozhe1!="")
            {
                model = model.Where(m => m.name.IndexOf(name1) >= 0);
            }
            dataGridView2.DataSource = model.ToList();**/
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form1 from = new Form1();
            from.id = Convert.ToString(this.dataGridView1.CurrentRow.Cells[0].Value);
            from.ShowDialog();//转换界面


        }

        private void dataGridView1_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            if (Convert.ToString(this.dataGridView1.CurrentRow.Cells[0].Value) != null)//转化类型
            {
                String sql = "delete from dbo.book where id =" + this.dataGridView1.CurrentRow.Cells[0].Value + "";
                SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
                MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
                DialogResult dr = MessageBox.Show("确定要删除吗?", "", messButton);
                if (dr == DialogResult.OK)//如果点击“确定”按钮
                {

                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();//执行

                    MessageBox.Show("删除成功");
                }
                else
                {
                    MessageBox.Show("删除失败");
                }
            }
            sqlConnection.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {



        }
        public void Display1()
        {
            DB.RenjiEntities db = new DB.RenjiEntities();
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "select id,username,type,name,sex,hobby from dbo.login where type='学生' ";//SQL语句实现表数据的读取

            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            DataSet dataSet = new DataSet(); //定义一个数据集
            SqlDataAdapter da = new SqlDataAdapter(sqlCommand);


            da.Fill(dataSet);   //填充数据集
            dataGridView3.DataSource = dataSet.Tables[0]; //填充数据进控件
            this.dataGridView3.Columns[0].DataPropertyName = dataSet.Tables[0].Columns[0].ToString();
            this.dataGridView3.Columns[1].DataPropertyName = dataSet.Tables[0].Columns[1].ToString();
            this.dataGridView3.Columns[2].DataPropertyName = dataSet.Tables[0].Columns[2].ToString();
            this.dataGridView3.Columns[3].DataPropertyName = dataSet.Tables[0].Columns[3].ToString();
            this.dataGridView3.Columns[4].DataPropertyName = dataSet.Tables[0].Columns[4].ToString();
            this.dataGridView3.Columns[5].DataPropertyName = dataSet.Tables[0].Columns[5].ToString();
            this.dataGridView3.Columns["id"].Visible = false;
            this.dataGridView3.Columns["username"].Visible = false;
            this.dataGridView3.Columns["type"].Visible = false;
            this.dataGridView3.Columns["name"].Visible = false;
            this.dataGridView3.Columns["sex"].Visible = false;

            this.dataGridView3.Columns["hobby"].Visible = false;

            this.dataGridView3.Columns["username"].Visible = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {


            Form5 form = new Form5();
            form.username = (string)this.dataGridView3.CurrentRow.Cells[1].Value;
            form.ShowDialog();




            Display1();



            //获取数据
         

         
        }

        private void button10_Click(object sender, EventArgs e)
        {
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            if (Convert.ToString(this.dataGridView3.CurrentRow.Cells[0].Value) != null)//转化类型
            {
                String sql = "delete from dbo.login where id =" + this.dataGridView3.CurrentRow.Cells[0].Value + "";
                SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
                MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
                DialogResult dr = MessageBox.Show("确定要删除吗?", "", messButton);
                if (dr == DialogResult.OK)//如果点击“确定”按钮
                {

                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();//执行

                    MessageBox.Show("删除成功");
                }
                else
                {

                }
            }
            sqlConnection.Close();
            Display1();
         
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form4 from = new Form4();
            from.username = Convert.ToString(this.dataGridView3.CurrentRow.Cells[1].Value);
            from.ShowDialog();//转换界面
        }





















    }
}

