﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;


namespace MIS
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        public string username;
        private void Form5_Load(object sender, EventArgs e)
        {
            Display();
        }
        public void Display()
        {
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "select d.id,b.name,b.bianhao,b.zuozhe,b.beizhu from dingdan d,book b where d.bookbianhao=b.bianhao and username='" + username + "'";//SQL语句实现表数据的读取
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            DataSet dataSet = new DataSet(); //定义一个数据集
            SqlDataAdapter da = new SqlDataAdapter(sqlCommand);
            da.Fill(dataSet);   //填充数据集
            dataGridView2.DataSource = dataSet.Tables[0]; //填充数据进控件


            this.dataGridView2.Columns[0].DataPropertyName = dataSet.Tables[0].Columns[0].ToString();
            this.dataGridView2.Columns[1].DataPropertyName = dataSet.Tables[0].Columns[1].ToString();
            this.dataGridView2.Columns[2].DataPropertyName = dataSet.Tables[0].Columns[2].ToString();
            this.dataGridView2.Columns[3].DataPropertyName = dataSet.Tables[0].Columns[3].ToString();
            this.dataGridView2.Columns[4].DataPropertyName = dataSet.Tables[0].Columns[4].ToString();
            this.dataGridView2.Columns["id"].Visible = false;

            this.dataGridView2.Columns["name"].Visible = false;
            this.dataGridView2.Columns["zuozhe"].Visible = false;

            this.dataGridView2.Columns["bianhao"].Visible = false;

            this.dataGridView2.Columns["beizhu"].Visible = false;
        }
        private void button6_Click(object sender, EventArgs e)
        {
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            if (Convert.ToString(this.dataGridView2.CurrentRow.Cells[0].Value) != null)//转化类型
            {
                String sql = "delete from dbo.dingdan where id =" + this.dataGridView2.CurrentRow.Cells[0].Value + "";
                SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
                MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
                DialogResult dr = MessageBox.Show("确定要归还吗?", "", messButton);
                if (dr == DialogResult.OK)//如果点击“确定”按钮
                {

                    SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();//执行

                    MessageBox.Show("归还成功");
                }
                else
                {

                }
            }
            sqlConnection.Close();
            Display();
        }
    }
}
