﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace MIS
{
    public partial class Geren : Form
    {
        public Geren()
        {
            InitializeComponent();
        }
        public string username;
        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            this.Close();
            Form2 form = new Form2();
            form.username = username;
            form.Show();
        }

        private void 查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Form3 form = new Form3();
            form.username = username;
            form.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Close();
            Geren form = new Geren();
            form.username = username;
            form.Show();
        }

        private void 切换账号ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            login f = new login();
            f.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void Display(){
            
            String myconn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";//数据库实例连接字符串
            SqlConnection sqlConnection = new SqlConnection(myconn);//新建数据库连接实例
            sqlConnection.Open();//打开数据库连接
            String sql = "select username,type,name,sex,hobby from dbo.login where username='" + username + "'";//SQL语句实现表数据的读取
            SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();//执行
            while (sqlDataReader.Read())
            {//满足用户名与密码一致，进入下一个界面
                label2.Text = (string)sqlDataReader[0];
                label4.Text = (string)sqlDataReader[1];
                label5.Text = (string)sqlDataReader[2];
                label7.Text = (string)sqlDataReader[3];
                label9.Text = (string)sqlDataReader[4];
        }
        }
        private void Geren_Load(object sender, EventArgs e)
        {

            Display();

            }
        

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 form = new Form4();
            form.username = username;
            form.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            Form5 form = new Form5();
            form.username = username;
            form.Show();
        }
    }
}
