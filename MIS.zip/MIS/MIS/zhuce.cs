﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace MIS
{
    public partial class zhuce : Form
    {
        public zhuce()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void zhuce_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

  private void button1_Click(object sender, EventArgs e)
        {
            String username, password,repassword,type;
            String sql = "";
            username = tbUsername.Text;
            password = tbPassWord.Text;
            repassword = tbrePassWord.Text;
            type = comboBox1.SelectedItem.ToString();
            if (password==repassword)//两次输入的密码一致
            {
                DB.RenjiEntities db = new DB.RenjiEntities();
               // string myConn = @"Data Source=JAY;Initial Catalog=Renji;Integrated Security=True";
                //SqlConnection sqlConnection = new SqlConnection(myConn);  //实例化连接对象
                //sqlConnection.Open();

                sql = "INSERT INTO dbo.login(username,password,type,name,sex,hobby) VALUES('" + username + "','" + password + "','" + type + "','" + "未设置" + "','" + "未设置" + "','" + "未设置" + "')";//SQL语句向表中写入数据
                //SqlCommand sqlCommand = new SqlCommand(sql, sqlConnection);
                //sqlCommand.ExecuteNonQuery();
                db.Database.ExecuteSqlCommand(sql);
                MessageBox.Show("注册成功");
                
            }
            else
            {
                MessageBox.Show("密码不一致");
            }
            //sqlConnection.Close();
        }
 
        private void button2_Click(object sender, EventArgs e)//返回登录界面
        {
            this.Close();
            login form = new login();
            form.Show();
        }


    }
}
